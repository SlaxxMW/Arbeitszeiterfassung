/* sw.js Hotfix 1.6.9: Service Worker mit Cache-Keys aktualisiert */
// Inhalt müsste hier den echten sw.js Hotfix-Code enthalten